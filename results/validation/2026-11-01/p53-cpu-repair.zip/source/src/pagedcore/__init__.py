"""PagedCore inference-serving engine."""
