from pathlib import Path
import hashlib,json,torch
torch.set_num_threads(1)
path=Path('results/local/p53-attention-probes.pt')
probes=torch.load(path,weights_only=True)
rows=[]
for case,probe in enumerate(probes):
 for layer,(q,k,v,target) in probe.items():
  native=q.reshape(4,8,64)@k[0].transpose(-1,-2)
  cast=(q.reshape(4,8,64).float()@k[0].float().transpose(-1,-2)).half()
  p=(native/8).float().softmax(-1).half()
  f32=(p.float()@v[0].float()).half().reshape_as(q).transpose(1,2)
  length=k.shape[2];parts=[torch.zeros(4,8,64) for _ in range(4)]
  for pos in range(length):
   lane=pos%4 if pos<length-length%4 else 0
   parts[lane].add_(p[:,:,pos,None].float()*v[0,:,pos,None,:].float())
  striped=(((parts[0]+parts[1])+parts[2])+parts[3]).half().reshape_as(q).transpose(1,2)
  rows.append(dict(case=case,cache_length=length,layer=layer,cast_score_mismatches=int((cast!=native).sum()),fp32_value_mismatches=int((f32!=target).sum()),striped_value_mismatches=int((striped!=target).sum())))
assert all(row['striped_value_mismatches']==0 for row in rows)
report=dict(scope='Pinned CPU matched-operand attention probes; not T4 evidence',input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),rows=rows)
Path('results/local/attention-reduction-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print('All',len(rows),'striped reductions match eager exactly; cast-score mismatches:',sum(r['cast_score_mismatches'] for r in rows),'FP32 grouped value mismatches:',sum(r['fp32_value_mismatches'] for r in rows))
