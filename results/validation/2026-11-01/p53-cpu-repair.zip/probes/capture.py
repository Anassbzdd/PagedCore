import sys,json,torch
from pathlib import Path
sys.path.insert(0,str(Path('scripts').resolve()))
from diagnose_paged_decode import component_controls
from pagedcore.config import MODEL_ID,MODEL_REVISION
from pagedcore.oracle import reference_math
from transformers import AutoModelForCausalLM
torch.set_num_threads(1)
with reference_math(),torch.inference_mode():
 m=AutoModelForCausalLM.from_pretrained(MODEL_ID,revision=MODEL_REVISION,torch_dtype=torch.float16,attn_implementation='eager',local_files_only=True).eval()
 ids=next(p['input_ids'] for p in json.loads(Path('tests/fixtures/reference_prompts.json').read_text())['prompts'] if p['name']=='maximum_output')
 probes=[]
 for length in (15,49):
  ref=m(torch.tensor([ids[:length]]),use_cache=True)
  token=ref.logits[:,-1:].argmax(-1)
  _,_,attention=component_controls(m,token,[ref]);probes.append(attention[0]);print(length,flush=True)
 torch.save(probes,'results/local/p53-attention-probes.pt')
