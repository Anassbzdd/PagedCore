set -euo pipefail
cd /kaggle/working/pagedcore-p53.FsjbbQ
export CUDA_VISIBLE_DEVICES=0 CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
.venv/bin/python -u - <<'PY'
import json
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM
from pagedcore.config import MODEL_ID, MODEL_REVISION
import pagedcore.decoder as decoder
from pagedcore.engine_types import RequestId, KVReservation
from pagedcore.kv_cache import KVAllocator
from pagedcore.oracle import reference_math
from pagedcore.weights import load_weights

original = decoder.paged_attention
mode = 'original'

def candidate(query, allocator, request, *, layer_index):
    pages=list(allocator.iter_layer_blocks(request,layer_index=layer_index))
    key=torch.cat([k for k,v in pages],0).transpose(0,1)[None]
    value=torch.cat([v for k,v in pages],0).transpose(0,1)[None]
    expected=decoder.dense_attention(query,key,value,torch.ones(1,1,1,key.shape[2],dtype=torch.bool,device=query.device))
    if mode == 'inspect' and len(pages)==1:
        k,v=pages[0]
        grouped=query.reshape(4,8,64)
        expanded_k=key.repeat_interleave(8,1)
        expanded_v=value.repeat_interleave(8,1)
        score_reference=(query @ expanded_k.transpose(-1,-2))/8
        score_group=((grouped @ k.permute(1,2,0))/8).reshape_as(score_reference)
        probability=score_reference.float().softmax(-1).half()
        score=score_group.float().reshape(4,8,-1)
        e=(score-score.amax(-1,keepdim=True)).exp()
        manual=(e/e.sum(-1,keepdim=True)).half().reshape_as(probability)
        partial=(probability.reshape(4,8,-1).float() @ v.transpose(0,1).float()).reshape_as(query).half()
        partial_half=(probability.reshape(4,8,-1) @ v.transpose(0,1)).reshape_as(query)
        print(json.dumps(dict(component_layer=layer_index,score_mismatch=(score_group!=score_reference).sum().item(),probability_mismatch=(manual!=probability).sum().item(),partial_fp32_mismatch=(partial!=expected).sum().item(),partial_fp16_mismatch=(partial_half!=expected).sum().item(),original_error=error(original(query,allocator,request,layer_index=layer_index),expected,2e-3))),flush=True)
    return expected

def error(actual,expected,tolerance):
    delta=(actual.float()-expected.float()).abs()
    ratio=delta/(tolerance+tolerance*expected.float().abs())
    return {'max_absolute_error':delta.max().item(),'max_tolerance_ratio':ratio.max().item(),'mismatches':(ratio>1).sum().item()}

import torch.nn.functional as F
original_project=decoder.project_qkv
original_output=decoder.output_projection
original_mlp=decoder.swiglu
original_logits=decoder.final_logits
is_decoding=False
def linear(x,w):
    return torch.bmm(x,w.T[None].expand(x.shape[0],-1,-1))
def project(x,w):
    if mode!='bmm_dense' or not is_decoding: return original_project(x,w)
    b,t,_=x.shape
    return tuple(linear(x,weight).view(b,t,heads,64).transpose(1,2) for weight,heads in ((w.q_proj,32),(w.k_proj,4),(w.v_proj,4)))
def output(x,w):
    if mode!='bmm_dense' or not is_decoding: return original_output(x,w)
    return linear(x.transpose(1,2).reshape(x.shape[0],1,2048),w.o_proj)
def mlp(x,w):
    if mode!='bmm_dense' or not is_decoding: return original_mlp(x,w)
    return linear(F.silu(linear(x,w.gate_proj))*linear(x,w.up_proj),w.down_proj)
def logits_fn(x,w):
    if mode!='bmm_dense' or not is_decoding: return original_logits(x,w)
    return linear(decoder.rms_norm(x,w.final_norm),w.lm_head)
decoder.project_qkv=project
decoder.output_projection=output
decoder.swiglu=mlp
decoder.final_logits=logits_fn

records=[]
with reference_math(), torch.inference_mode():
    weights=load_weights(device='cuda:0')
    model=AutoModelForCausalLM.from_pretrained(MODEL_ID,revision=MODEL_REVISION,torch_dtype=torch.float16,attn_implementation='eager').to('cuda:0').eval()
    ids=next(c['input_ids'] for c in json.loads(Path('tests/fixtures/reference_prompts.json').read_text())['prompts'] if c['name']=='maximum_output')
    for mode in ('inspect','bmm_dense'):
        decoder.paged_attention=candidate
        for lengths in ((15,),(1,15,16,17,49)):
            pool=torch.full((22,2,16,16,4,64),torch.nan,dtype=torch.float16,device='cuda:0')
            allocator=KVAllocator(pool)
            requests=tuple(RequestId(str(r)) for r in range(len(lengths)))
            references={}
            for request,length in zip(requests,lengths):
                allocator.create(KVReservation(request,(length+18)//16))
                inputs=torch.tensor([ids[:length]],device='cuda:0')
                references[request]=model(inputs,use_cache=True)
                decoder.prefill_paged(inputs,weights,allocator,request)
            for step in range(3):
                order=requests if step%2==0 else requests[::-1]
                tokens=torch.cat([references[r].logits[:,-1:].argmax(-1) for r in order])
                expected={r:model(tokens[row:row+1],past_key_values=references[r].past_key_values,use_cache=True) for row,r in enumerate(order)}
                is_decoding=True
                actual=decoder.decode_paged(tokens,weights,allocator,order)
                is_decoding=False
                for row,request in enumerate(order):
                    record=dict(mode=mode,lengths=lengths,step=step,row=row,request=str(request),logits=error(actual[row:row+1],expected[request].logits,5e-3),greedy_matches=torch.equal(actual[row:row+1].argmax(-1),expected[request].logits.argmax(-1)))
                    worst={'max_tolerance_ratio':0}
                    first_failure=None
                    for logical,physical in enumerate(allocator.block_table(request)):
                        key,value=allocator.read_block(request,logical)
                        start=logical*16; stop=start+key.shape[1]
                        for layer,(k,v) in enumerate(expected[request].past_key_values):
                            for kind,a,e in (('key',key[layer],k),('value',value[layer],v)):
                                measurement=error(a,e[0,:,start:stop].transpose(0,1),2e-3)
                                measurement.update(layer=layer,kind=kind,block=logical)
                                if measurement['max_tolerance_ratio']>worst['max_tolerance_ratio']: worst=measurement
                                if measurement['mismatches'] and first_failure is None: first_failure=measurement
                    record.update(worst_kv=worst,first_kv_failure=first_failure)
                    records.append(record)
                    print(json.dumps(record),flush=True)
                    references[request]=expected[request]
            for request in requests: allocator.release_all(request)
    decoder.paged_attention=original
Path('results/local/paged-decode-component-diagnostic.json').write_text(json.dumps(records,indent=2))
print('DIAGNOSTIC_COMPLETE')
PY