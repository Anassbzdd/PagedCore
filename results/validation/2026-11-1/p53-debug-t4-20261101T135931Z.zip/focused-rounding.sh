set -euo pipefail
cd /kaggle/working/pagedcore-p53.FsjbbQ
export CUDA_VISIBLE_DEVICES=0 CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
.venv/bin/python -u - <<'PY'
import json
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM
from pagedcore.config import MODEL_ID, MODEL_REVISION
import pagedcore.decoder as decoder
from pagedcore.engine_types import RequestId, KVReservation
from pagedcore.kv_cache import KVAllocator
from pagedcore.oracle import reference_math
from pagedcore.weights import load_weights

original = decoder.paged_attention
mode = 'original'

def candidate(query, allocator, request, *, layer_index):
    pages=list(allocator.iter_layer_blocks(request,layer_index=layer_index))
    if mode == 'dense_reference':
        key=torch.cat([k for k,v in pages],0).transpose(0,1)[None]
        value=torch.cat([v for k,v in pages],0).transpose(0,1)[None]
        return decoder.dense_attention(query,key,value,torch.ones(1,1,1,key.shape[2],dtype=torch.bool,device=query.device))
    grouped=query.reshape(4,8,64)
    def scores(key):
        return ((grouped @ key.permute(1,2,0))/8).float()
    if mode == 'one_page_eager' and len(pages)==1:
        key,value=pages[0]
        probability=scores(key).softmax(-1).half()
        return (probability @ value.transpose(0,1)).reshape(1,32,1,64)
    maximum=torch.full((4,8,1),-torch.inf,device=query.device)
    denominator=torch.zeros_like(maximum)
    numerator=torch.zeros_like(grouped,dtype=torch.float32)
    for key,value in pages:
        score=scores(key)
        updated=torch.maximum(maximum,score.amax(-1,keepdim=True))
        denominator=denominator*(maximum-updated).exp() + (score-updated).exp().sum(-1,keepdim=True)
        maximum=updated
    reciprocal=denominator.reciprocal()
    for key,value in pages:
        probability=((scores(key)-maximum).exp()*reciprocal).half()
        if mode == 'reciprocal_value':
            numerator += (probability @ value.transpose(0,1)).float()
        else:
            numerator += probability.float() @ value.transpose(0,1).float()
    return numerator.reshape(1,32,1,64).half()

def error(actual,expected,tolerance):
    delta=(actual.float()-expected.float()).abs()
    ratio=delta/(tolerance+tolerance*expected.float().abs())
    return {'max_absolute_error':delta.max().item(),'max_tolerance_ratio':ratio.max().item(),'mismatches':(ratio>1).sum().item()}

records=[]
with reference_math(), torch.inference_mode():
    weights=load_weights(device='cuda:0')
    model=AutoModelForCausalLM.from_pretrained(MODEL_ID,revision=MODEL_REVISION,torch_dtype=torch.float16,attn_implementation='eager').to('cuda:0').eval()
    ids=next(c['input_ids'] for c in json.loads(Path('tests/fixtures/reference_prompts.json').read_text())['prompts'] if c['name']=='maximum_output')
    for mode in ('dense_reference','reciprocal','reciprocal_value','one_page_eager'):
        decoder.paged_attention=candidate
        for lengths in ((15,),(1,15,16,17,49)):
            pool=torch.full((22,2,16,16,4,64),torch.nan,dtype=torch.float16,device='cuda:0')
            allocator=KVAllocator(pool)
            requests=tuple(RequestId(str(r)) for r in range(len(lengths)))
            references={}
            for request,length in zip(requests,lengths):
                allocator.create(KVReservation(request,(length+18)//16))
                inputs=torch.tensor([ids[:length]],device='cuda:0')
                references[request]=model(inputs,use_cache=True)
                decoder.prefill_paged(inputs,weights,allocator,request)
            for step in range(3):
                order=requests if step%2==0 else requests[::-1]
                tokens=torch.cat([references[r].logits[:,-1:].argmax(-1) for r in order])
                expected={r:model(tokens[row:row+1],past_key_values=references[r].past_key_values,use_cache=True) for row,r in enumerate(order)}
                actual=decoder.decode_paged(tokens,weights,allocator,order)
                for row,request in enumerate(order):
                    record=dict(mode=mode,lengths=lengths,step=step,row=row,request=str(request),logits=error(actual[row:row+1],expected[request].logits,5e-3),greedy_matches=torch.equal(actual[row:row+1].argmax(-1),expected[request].logits.argmax(-1)))
                    worst={'max_tolerance_ratio':0}
                    first_failure=None
                    for logical,physical in enumerate(allocator.block_table(request)):
                        key,value=allocator.read_block(request,logical)
                        start=logical*16; stop=start+key.shape[1]
                        for layer,(k,v) in enumerate(expected[request].past_key_values):
                            for kind,a,e in (('key',key[layer],k),('value',value[layer],v)):
                                measurement=error(a,e[0,:,start:stop].transpose(0,1),2e-3)
                                measurement.update(layer=layer,kind=kind,block=logical)
                                if measurement['max_tolerance_ratio']>worst['max_tolerance_ratio']: worst=measurement
                                if measurement['mismatches'] and first_failure is None: first_failure=measurement
                    record.update(worst_kv=worst,first_kv_failure=first_failure)
                    records.append(record)
                    print(json.dumps(record),flush=True)
                    references[request]=expected[request]
            for request in requests: allocator.release_all(request)
    decoder.paged_attention=original
Path('results/local/paged-decode-focused-diagnostic.json').write_text(json.dumps(records,indent=2))
print('DIAGNOSTIC_COMPLETE')
PY