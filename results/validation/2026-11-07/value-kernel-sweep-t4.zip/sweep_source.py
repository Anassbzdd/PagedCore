
"""Synthetic dense reference multiply diagnostics; run outside owned decode."""

import argparse
import hashlib
import json
import random
import traceback
from datetime import UTC, datetime
from itertools import permutations
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
import torch

from pagedcore.cli import collect_environment_diagnostics, collect_validation_provenance
from pagedcore.oracle import reference_math

LENGTHS = sorted(
    set(range(3, 34))
    | {
        47,
        48,
        49,
        63,
        64,
        65,
        95,
        96,
        97,
        127,
        128,
        129,
        255,
        256,
        257,
        511,
        512,
        513,
        1023,
        1024,
        1025,
        2047,
        2048,
    }
)
COORDINATES = [(0, 0), (2, 41), (7, 63), (8, 19), (20, 19), (31, 63)]


def trial_positions(length, samples):
    if length <= 20:
        return list(permutations(range(length), 3))
    rng = random.Random(20261107 + length)
    positions = set()
    # Include page edges as well as widely separated positions.
    edges = sorted(
        {0, 1, length - 2, length - 1}
        | {
            x
            for boundary in range(16, length, 16)
            for x in (boundary - 1, boundary)
            if 0 <= x < length
        }
    )
    for _ in range(samples // 2):
        positions.add(tuple(rng.sample(edges, 3)))
    while len(positions) < min(samples, length * (length - 1) * (length - 2)):
        positions.add(tuple(rng.sample(range(length), 3)))
    return sorted(positions)


def predictions(products):
    length = products.shape[-1]
    result = {"fp64": products.astype(np.float64).sum(-1).astype(np.float16)}
    for lanes in (1, 2, 4, 8, 16, 32):
        partials = np.zeros((lanes, products.shape[0]), dtype=np.float32)
        tail = length - length % lanes
        for slot in range(length):
            partials[slot % lanes if slot < tail else 0] += products[:, slot]
        total = partials[0].copy()
        for partial in partials[1:]:
            total += partial
        result[f"striped_{lanes}"] = total.astype(np.float16)
    return result


def profile_product(p, v):
    activities = [torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]
    with torch.profiler.profile(activities=activities) as prof:
        out = p @ v
        torch.cuda.synchronize(p.device)
    names = sorted({event.name for event in prof.events() if "CUDA" in str(event.device_type)})
    return out, names


@torch.inference_mode()
def run_length(length, samples, device):
    positions = trial_positions(length, samples)
    vectors = torch.zeros(len(positions), length, dtype=torch.float16)
    vectors.scatter_(
        1,
        torch.tensor(positions),
        torch.tensor([32768, -32768, 2**-14], dtype=torch.float16).expand(len(positions), -1),
    )
    p = torch.full((1, 32, 1, length), 1 / 32, dtype=torch.float16, device=device)
    v = torch.empty((1, 32, length, 64), dtype=torch.float16, device=device)
    heads, channels = torch.tensor(COORDINATES, device=device).T
    observed = []
    for vector in vectors.to(device):
        v.copy_(vector[None, None, :, None])
        observed.append((p @ v).reshape(32, 64)[heads, channels])
    actual = torch.stack(observed).cpu().numpy()
    synthetic_kernels = profile_product(p, v)[1] if p.is_cuda else []
    models = predictions(vectors.float().numpy() / 32)
    mismatches = {
        name: (expected[:, None] != actual).sum(0).tolist() for name, expected in models.items()
    }

    # Separate random operands test real magnitudes beyond cancellation patterns.
    generator = torch.Generator().manual_seed(20261107 + length)
    random_p = torch.randn((1, 32, 1, length), generator=generator).softmax(-1).half().to(device)
    random_v = torch.randn((1, 32, length, 64), generator=generator).half().to(device)
    if p.is_cuda:
        random_output, random_kernels = profile_product(random_p, random_v)
    else:
        random_output, random_kernels = random_p @ random_v, []
    selected_p = random_p[0, heads, 0].cpu()
    selected_v = random_v[0, heads, :, channels].cpu()
    selected_output = random_output.reshape(32, 64)[heads, channels].cpu().numpy()
    random_models = predictions(selected_p.float().numpy() * selected_v.float().numpy())
    return {
        "length": length,
        "p_shape": list(p.shape),
        "p_stride": list(p.stride()),
        "v_shape": list(v.shape),
        "v_stride": list(v.stride()),
        "synthetic_kernels": synthetic_kernels,
        "random_kernels": random_kernels,
        "shared_kernels": sorted(set(synthetic_kernels) & set(random_kernels)),
        "coordinates": COORDINATES,
        "probability": 1 / 32,
        "values_in_trial_order": [32768, -32768, 2**-14],
        "trial_positions": positions,
        "observed_outputs": actual.tolist(),
        "mismatches_per_coordinate": mismatches,
        "random_probabilities": selected_p.tolist(),
        "random_values": selected_v.tolist(),
        "random_outputs": selected_output.tolist(),
        "random_model_outputs": {name: value.tolist() for name, value in random_models.items()},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", choices=("cpu", "cuda:0"), default="cuda:0")
    parser.add_argument("--lengths", default=",".join(map(str, LENGTHS)))
    parser.add_argument("--samples", type=int, default=512)
    parser.add_argument(
        "--output", type=Path, default=Path("/kaggle/working/value-kernel-sweep.zip")
    )
    args = parser.parse_args()
    lengths = sorted(set(map(int, args.lengths.split(","))))
    if not lengths or not all(3 <= n <= 2048 for n in lengths) or args.samples < 1:
        parser.error("lengths must be 3..2048 and samples must be positive")
    if args.device != "cpu":
        assert torch.cuda.is_available() and torch.cuda.device_count() == 1
        assert "T4" in torch.cuda.get_device_name(0), "requires the pinned T4"
        assert torch.__version__ == "2.7.1+cu126", "requires the pinned Torch version"
    torch.set_num_threads(1)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    source = Path(__file__).read_bytes()
    with reference_math() as policy, ZipFile(args.output, "w", compression=ZIP_DEFLATED) as archive:
        archive.writestr("sweep_source.py", source)
        archive.writestr(
            "metadata.json",
            json.dumps(
                {
                    "scope": "Synthetic dense P@V sweep; sampled coordinates, not decoder acceptance",
                    "captured_at_utc": datetime.now(UTC).isoformat(),
                    "lengths": lengths,
                    "source_sha256": hashlib.sha256(source).hexdigest(),
                    "device": args.device,
                    "math_policy": policy,
                    "environment": collect_environment_diagnostics(),
                    "provenance": collect_validation_provenance(),
                },
                indent=2,
            ),
        )
        failures = []
        for length in lengths:
            try:
                record = run_length(length, args.samples, args.device)
            except Exception:
                failures.append(length)
                archive.writestr(f"error-length-{length}.txt", traceback.format_exc())
                print(f"FAILED length={length}; traceback retained", flush=True)
                continue
            archive.writestr(f"length-{length}.json", json.dumps(record))
            print(
                json.dumps(
                    {
                        "length": length,
                        "trials": len(record["trial_positions"]),
                        "mismatches_total": {
                            k: sum(v) for k, v in record["mismatches_per_coordinate"].items()
                        },
                        "shared_kernels": record["shared_kernels"],
                    }
                ),
                flush=True,
            )
    print("REPORT", args.output, flush=True)
    if failures:
        raise SystemExit(f"Failed lengths {failures}; retain the archive")


if __name__ == "__main__":
    main()

