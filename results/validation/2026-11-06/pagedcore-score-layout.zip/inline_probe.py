
import gc
import json
import runpy
import subprocess
from importlib.metadata import version
from pathlib import Path
from unittest.mock import patch
from zipfile import ZIP_DEFLATED, ZipFile

import torch
from transformers.models.llama.modeling_llama import repeat_kv

import pagedcore.attention as attention
import pagedcore.decoder as decoder
from pagedcore.determinism import seed_everything
from scripts import diagnose_paged_decode as diag

torch.set_num_threads(1)
guard = runpy.run_path("tests/conftest.py")["_BlockwiseKVGuard"]
base_controls = diag.component_controls
base_decode = diag.decode_paged
base_attention = decoder.paged_attention
base_value = attention._eager_value_sum

def page_fp64(p, allocator, request, layer):
    total = torch.zeros((4, 8, 64), dtype=torch.float64, device=p.device)
    start = 0
    for _, value in allocator.iter_layer_blocks(request, layer_index=layer):
        stop = start + value.shape[0]
        total = torch.baddbmm(
            total, p[..., start:stop].double(), value.transpose(0, 1).double()
        )
        start = stop
    return total.reshape(1, 32, 1, 64).half()


def compare_score_products(query, key, hf_p, owned_p):
    length = key.shape[-2]
    head_query = query.reshape(4, 8, 64)
    reference = query @ repeat_kv(key, 8).transpose(-2, -1)
    scale = 64**-0.5
    assert torch.equal((reference * scale).softmax(-1, dtype=torch.float32).half(), hf_p)

    chunks = {name: [] for name in ("native8", "packed_page", "shared_full_width", "packed_full_width")}
    for start in range(0, length, 16):
        page = key[0, :, start:start + 16].contiguous()
        valid = page.shape[1]
        padded = page
        if start and valid < 16:
            padded = page.new_zeros((4, 16, 64))
            padded[:, :valid].copy_(page)
        native = [
            torch.bmm(head_query[group, :, None], padded[group].T[None].expand(8, -1, -1))
            for group in range(4)
        ]
        chunks["native8"].append(torch.stack(native)[..., :valid].reshape(1, 32, 1, valid))
        packed = query @ repeat_kv(padded[None], 8).transpose(-2, -1)
        chunks["packed_page"].append(packed[..., :valid])

        # Independent reference-only scratch. Keep only this page's real keys.
        masked = torch.zeros_like(key)
        masked[..., start:start + valid, :] = key[..., start:start + valid, :]
        shared = [
            torch.bmm(head_query[group, :, None], masked[0, group].T[None].expand(8, -1, -1))
            for group in range(4)
        ]
        chunks["shared_full_width"].append(
            torch.stack(shared)[..., start:start + valid].reshape(1, 32, 1, valid)
        )
        packed_full = query @ repeat_kv(masked, 8).transpose(-2, -1)
        chunks["packed_full_width"].append(packed_full[..., start:start + valid])

    comparisons = {}
    for name, pages in chunks.items():
        raw = torch.cat(pages, dim=-1)
        p = (raw * scale).float().softmax(-1).half()
        if name == "native8":
            assert torch.equal(p, owned_p), "Score replay did not reproduce owned probabilities"
        bad = (raw != reference).nonzero()
        entry = {
            "raw_unequal": bad.shape[0],
            "rounded_p_unequal": (p != hf_p).count_nonzero().item(),
        }
        if len(bad):
            index = tuple(bad[0].tolist())
            entry["first_raw_difference"] = {
                "head": index[1], "token": index[-1],
                "actual": raw[index].item(), "hf": reference[index].item(),
            }
        comparisons[name] = entry
    return comparisons


def layout(x):
    return {"shape": list(x.shape), "stride": list(x.stride()), "dtype": str(x.dtype)}

def run_arm(mode):
    seed_everything(0)
    captures = []
    calls = []

    def controls(*args):
        expected, rows, captured = base_controls(*args)
        captures[:] = captured
        return expected, rows, captured

    def decode(tokens, weights, allocator, requests):
        targets = dict(zip(requests, captures, strict=True))
        rows = {
            r: {"request": str(r), "attended": allocator.cached_length(r) + 1,
                "layers": []}
            for r in requests
        }
        # Prepare independent reference tensors outside the guarded owned forward.
        expanded = {
            (r, layer): repeat_kv(saved[2], 8)
            for r, layers in targets.items() if rows[r]["attended"] > 16
            for layer, saved in layers.items()
        } if mode == "native_same_v" else {}

        def observe(q, cache, request, *, layer_index, eager_rounding):
            hq, hk, hv, hout, _, hp = targets[request][layer_index]
            checks = {"layer": layer_index, "q_equal": torch.equal(q, hq)}

            def reduce(p, alloc, req, layer):
                p4 = p.reshape_as(hp).contiguous()
                start = 0
                k_equal = v_equal = True
                page_layouts = []
                for key, value in alloc.iter_layer_blocks(req, layer_index=layer):
                    stop = start + value.shape[0]
                    k_equal &= torch.equal(key, hk[0, :, start:stop].transpose(0, 1))
                    v_equal &= torch.equal(value, hv[0, :, start:stop].transpose(0, 1))
                    if layer == 0:
                        page_layouts.append(layout(value))
                    start = stop
                assert start == p.shape[-1] == hp.shape[-1]
                checks.update(k_equal=k_equal, v_equal=v_equal, p_equal=torch.equal(p4, hp))
                if checks["q_equal"] and k_equal:
                    checks["score_products"] = compare_score_products(hq, hk, hp, p4)
                if layer == 0:
                    checks["layouts"] = {
                        "owned_q": layout(q), "owned_p": layout(p), "pages": page_layouts,
                        "hf_q": layout(hq), "hf_k": layout(hk),
                        "hf_v": layout(hv), "hf_p": layout(hp),
                    }
                ref_v = expanded.get((req, layer))
                if ref_v is not None and v_equal:
                    assert p4.stride() == hp.stride()
                    checks["used_hf_p"] = checks["q_equal"] and k_equal and not checks["p_equal"]
                    out = (hp if checks["used_hf_p"] else p4) @ ref_v
                    checks["reducer"] = "native_same_v"
                    if checks["p_equal"] or checks["used_hf_p"]:
                        assert torch.equal(out.transpose(1, 2), hout)
                    return out

                checks["reducer"] = "fallback" if ref_v is not None else mode
                return base_value(p, alloc, req, layer)

            with patch.object(attention, "_eager_value_sum", reduce):
                out = base_attention(
                    q, cache, request, layer_index=layer_index, eager_rounding=eager_rounding
                )
            checks["out_equal"] = torch.equal(out.transpose(1, 2), hout)
            rows[request]["layers"].append(checks)
            return out

        with patch.object(decoder, "paged_attention", observe), guard(allocator._pool):
            logits = base_decode(tokens, weights, allocator, requests)
        calls.append(list(rows.values()))
        return logits

    reducer = page_fp64 if mode == "fp64" else attention._multi_page_value_sum
    with (
        patch.object(diag, "component_controls", controls),
        patch.object(diag, "decode_paged", decode),
        patch.object(attention, "_multi_page_value_sum", reducer),
    ):
        report = diag.run("cuda:0", steps=3)
    report["experiment_arm"] = "score_layout_control"
    report["integrated_layer_checks_by_call"] = calls
    result = report["summaries"]["integrated"]
    print("PARITY", mode, json.dumps(result), flush=True)
    return report

output = Path("/kaggle/working/pagedcore-score-layout.zip")
device = subprocess.check_output(
    ["nvidia-smi", "--query-gpu=name,uuid,driver_version", "--format=csv,noheader"],
    text=True,
).strip()
with ZipFile(output, "w", compression=ZIP_DEFLATED) as archive:
    archive.writestr("runtime.json", json.dumps({
        "cublas_wheel": version("nvidia-cublas-cu12"), "nvidia_smi": device,
    }, indent=2))
    for mode in ("native_same_v",):
        report = run_arm(mode)
        archive.writestr(f"{mode}.json", json.dumps(report))
        integrated = report["summaries"]["integrated"]
        passed = integrated["max_tolerance_ratio"] <= 1 and integrated["all_greedy_matches"]
        del report
        gc.collect()
        torch.cuda.empty_cache()
        if mode == "striped" and passed:
            print("Baseline did not reproduce. Check runtime provenance.", flush=True)
            break
        if mode == "fp64" and passed:
            break
print("REPORT", output)
